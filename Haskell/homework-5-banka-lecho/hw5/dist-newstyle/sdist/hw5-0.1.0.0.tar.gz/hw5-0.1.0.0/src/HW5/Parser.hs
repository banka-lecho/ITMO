module HW5.Parser
  ( parse
  ) where

import Data.Void (Void)
import Text.Megaparsec.Error (ParseErrorBundle)

import HW5.Base (HiExpr)

parse :: String -> Either (ParseErrorBundle String Void) HiExpr
parse = runParser parse' ""

parse' :: Parser HiExpr
parse' = do
  expr <- parse''
  _ <- skipSpace eof
  return expr

parse'' :: Parser HiExpr
parse'' = makeExprParser token' operTable

operTable :: [[Operator Parser HiExpr]]
operatorTable =
  [ [ binL "*" HiFunMul
    , binLNotFollow "/" HiFunDiv "="
    ]
  , [ binL "+" HiFunAdd
    , binL "-" HiFunSub
    ]
  ]
  where
     binary :: (Parser (HiExpr -> HiExpr -> HiExpr) -> Operator Parser HiExpr) -> HiFun -> String -> Operator Parser HiExpr
     binary infx f str = infx $ (\a b -> HiExprApply (HiExprValue $ HiValueFunction f) [a, b]) <$ (lexeme . try) (string name <* notFollowedBy "=")

     binL :: HiFun -> String -> Operator Parser HiExpr
     binL = binary InfixL

type Parser = Parsec Void String

skipSpace :: Parser a -> Parser a
skipSpace p = space *> p <* space

lexeme :: Parser a -> Parser a
lexeme = L.lexeme spaceConsumer

hiExpr :: Parser HiExpr
hiExpr = do
  name <- choice
    [ try prnth
    , HiExprValue <$> skipSpace hiVal
    ]
  skipSpace $ hiExpr' name

hiExpr' :: HiExpr -> Parser HiExpr
hiExpr' name = do
    a <- skipSpace $ choice [args name, runs name]
    skipSpace $ choice
        [ hiExpr' a
        , return a
        ]


prnth :: Parser HiExpr
prnth = string "(" *> parse'' <* string ")"

token' :: Parser HiExpr
token' = skipSpace $ choice
  [ try hiExpr
  , prnth
  , try (HiExprValue <$> hiVal)
  , hiList
  ]
