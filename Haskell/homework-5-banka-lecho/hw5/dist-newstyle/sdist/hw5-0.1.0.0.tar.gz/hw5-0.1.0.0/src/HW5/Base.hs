module HW5.Base
  ( HiError
  , HiExpr
  , HiFun
  , HiValue
  ) where

data HiFun = HiFunDiv
  | HiFunMul
  | HiFunAdd
  | HiFunSub
  deriving (Eq, Ord, Enum, Bounded)
 
 
data HiValue = HiValueNumber Rational
  | HiValueFunction HiFun
  deriving (Eq, Ord)
 
data HiExpr = HiExprValue HiValue
  | HiExprApply HiExpr [HiExpr]
  deriving (Eq, Ord)
 
data HiError = HiErrorInvalidArgument
  | HiErrorInvalidFunction
  | HiErrorArityMismatch
  | HiErrorDivideByZero
  deriving (Eq, Ord)
